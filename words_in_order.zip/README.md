**Run the dependencies by using the following command**
### `npm i`

**Run the app by using the following command**
### `npm start`

**Launch the test runner by using the following command**
### `npm test`